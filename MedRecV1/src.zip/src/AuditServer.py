from flask import Flask, request, session, render_template, make_response, redirect, url_for
from prometheus_flask_exporter import PrometheusMetrics
from flask_cors import CORS
from datetime import timedelta
from random import randint
import os
import pypyodbc
from DoctorModel import DoctorModel
from PatientModel import PatientModel
from EHRRecordModel import EHRRecordModel
from UserModel import UserModel
import smtplib, ssl
import json
from web3 import Web3

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'
#session.pop('username', None)
metrics = PrometheusMetrics(app)
CORS(app)

msgText = ""
msgType = ""
otp = ""
doc_email = ""
isDoc = None


def verifyNonce(nonce, fro):
    print(nonce + fro)
    w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
    w3.eth.defaultAccount = w3.eth.accounts[1]
    if nonce == "Set nonce value":
        return 0
    conn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1',
        autocommit=True)
    cur1 = conn1.cursor()
    sqlcmd1 = "SELECT * FROM Transactions WHERE hash = '" + nonce + "' ";
    print(sqlcmd1)
    cur1.execute(sqlcmd1)
    row = cur1.fetchone()
    cur1.commit()
    if not row:
        try:
            trans = w3.eth.getTransaction(nonce)
            print(trans['hash'])
            if (trans['hash'].hex() == nonce) and (trans['from'] == fro):
                #sqlcmd1 = "INSERT INTO Transactions VALUES('" + nonce + "')";
                # print(sqlcmd1)
                # cur1.execute(sqlcmd1)
                return 1
            else:
                return 0

        except Exception as e:
            return 0
    print("Already Exists")
    return 0


@app.route("/")
def home():
    global msgText, msgType, otp, doc_email
    return render_template('Login.html')

@app.route("/DoctorLogin")
def home_doctor():
    global msgText, msgType, otp, doc_email
    return render_template('DoctorLogin.html')

@app.route("/test", methods=['GET'])
def test():
    w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
    w3.eth.defaultAccount = w3.eth.accounts[1]
    print(w3.eth.sendTransaction({'from':w3.eth.defaultAccount, 'to':w3.eth.accounts[2], 'value': Web3.toWei(0.00002, "ether")}))

    # Get stored abi and contract_address
    # with open("data.json", 'r') as f:
    #     datastore = json.load(f)
    #     abi = datastore["abi"]
    #     contract_address = datastore["contract_address"]
    # contract = w3.eth.contract(address=contract_address, abi=abi)
    # contract.functions.setUser(
    #     "Ram","male"
    # ).transact()
    # user_data = contract.functions.getUser().call()
    # print(user_data)
    # contract.functions.addFiles(1,["hello","how","are"]).transact()
    # files = contract.functions.getFiles(1).call()
    # print(files)
    return 'Okay'

@app.route("/OTPGeneration", methods=['GET'])
def OTPGeneration():
    global doc_email, otp
    print(request)
    doc_email = request.args['email']
    conn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1',autocommit=True)
    cur1 = conn1.cursor()
    sqlcmd1 = "SELECT doctorName FROM Doctors WHERE emailid = '" + doc_email + "' ";
    print(sqlcmd1)
    cur1.execute(sqlcmd1)
    row = cur1.fetchone()
    cur1.commit()
    if row:

        port = 465  # For SSL
        smtp_server = "smtp.gmail.com"
        sender_email = "nijamathan@gmail.com"  # Enter your address
        receiver_email = doc_email  # Enter receiver address
        password = "harivishak"
        #input("Type your password and press enter: ")

        name = row[0]
        otp = str(randint(100000,999999))
        subject = "MedicalRecord Login"
        message_text = "Dear "+name+",\n\nYour MedicalRecord login OTP is: "+otp
        message = """From:<%s>\nTo:<%s>\nSubject:%s\n%s""" % (sender_email,receiver_email,subject,message_text)

        try:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, message)
            return 'OTP sent to mail id'

        except smtplib.SMTPException as e:
            print(e)
            return 'Error. Please try again'
    return 'Mail id not registered. Enter a valid one'


@app.route("/Dashboard", methods=['GET'])
def Dashboard():
    if 'username' in session:
        if isDoc:
            resp = make_response(render_template('Dashboard.html', template = "DocCommon.html"))
        else:
            resp = make_response(render_template('Dashboard.html', template="Common.html"))
        resp.headers["Cache-Control"] = "no-store"
        print(session.permanent)
        print(request.cookies)
        return resp
    return render_template('ErrorPage.html')



@app.route("/AuthenticateLogin", methods=['POST'])
def AuthenticateLogin():
    global msgText, msgType
    emailid = request.form['emailid']
    password = request.form['password']
    nonce = request.form['nonce']
    fro = request.form['from']
    if not verifyNonce(nonce, fro):
        return '<h3>Blockchain verification failed. Please try again <a href =/>Login</a></h3>'

    conn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cur1 = conn1.cursor()
    sqlcmd1 = "SELECT * FROM Users WHERE emailid = '"+emailid+"' AND password = '"+password+"'";
    print(sqlcmd1)
    cur1.execute(sqlcmd1)
    row = cur1.fetchone()
    cur1.commit()
    if row:
        session.new = True
        session['username'] = emailid
        print(request.form)
        if 'remember' in request.form:
            session.permanent = True
            app.permanent_session_lifetime = timedelta(days=2)
            print('yes')
        else:
            session.permanent = True
            app.permanent_session_lifetime = timedelta(seconds=10)
        return redirect("/Dashboard")
    return '<h2>Invalid credentials. Please try again <a href =/>Login</a></h3>'

@app.route("/AuthenticateDoctorLogin", methods=['POST'])
def AuthenticateDoctorLogin():
    global otp, doc_email, isDoc
    emailid = request.form['emailid']
    OTP = request.form['otp']
    nonce = request.form['nonce']
    fro = request.form['from']
    if(not verifyNonce(nonce,fro)):
        return '<h3>Blockchain verification failed. Please try again <a href =/>Login</a></h3>'
    print(request.form)
    print(otp+doc_email)
    if (emailid == doc_email) and (otp == OTP):
        session.new = True
        session['username'] = emailid
        print(request.form)
        if 'remember' in request.form:
            session.permanent = True
            app.permanent_session_lifetime = timedelta(days=2)
            print('yes')
        else:
            session.permanent = True
            app.permanent_session_lifetime = timedelta(seconds=10)
        isDoc = True
        return redirect("/Dashboard")
    return '<h3>Incorrect Details. Please try again <a href =/DoctorLogin>Login</a></h3>'

@app.route("/LogOut", methods=['GET'])
def LogOut():
    global isDoc
    session.pop('username', None)
    isDoc = False
    return redirect('/')


@app.route("/UserListing")

def UserListing():
    global msgText, msgType
    print("UserListing Called")
    searchData = request.args.get('searchData')
    if searchData == None:
        searchData = "";
    conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cursor = conn2.cursor()
    sqlcmd1 = "SELECT * FROM Users WHERE emailid like '%"+searchData+"%'"
    print(sqlcmd1)
    cursor.execute(sqlcmd1)
    records = []
    
    while True:
        dbrow = cursor.fetchone()
        if not dbrow:
            break
        row = UserModel(dbrow[0], dbrow[1], dbrow[2], dbrow[3])
        records.append(row)
    if 'username' in session:
        return render_template('UserListing.html', records=records, searchData=searchData)
    return render_template('ErrorPage.html')



@app.route("/UserOperation")
def UserOperation():
    global msgText, msgType
    operation = request.args.get('operation')
    unqid = ""
    row = UserModel(0, "", "", "")
    
    if operation != "Create" :
        unqid = request.args.get('unqid').strip()
        conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
        cursor = conn2.cursor()
        sqlcmd1 = "SELECT * FROM Users WHERE userID = '"+unqid+"'"
        cursor.execute(sqlcmd1)
        dbrow = cursor.fetchone()
        if dbrow:
            print("dbrow[0]", dbrow[0])
            row = UserModel(dbrow[0], dbrow[1], dbrow[2], dbrow[3])
    if 'username' in session:
        return render_template('UserOperation.html', row = row, operation=operation )
    return render_template('ErrorPage.html')


@app.route("/ProcessUserOperation",methods = ['POST'])
def ProcessUserOperation():
    global msgText, msgType
    print(request.form)
    operation = request.form['operation']
    isCloudAuditor = 0
    if operation != "Delete" :
        print('OKKK')
        emailid= request.form['emailid']
        password= request.form['password']
        if request.form.get("isCloudAuditor") != None :
            isCloudAuditor = 1

    unqid = request.form['unqid'].strip()
    
    
    conn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cur1 = conn1.cursor()
    

    if operation == "Create" :
        sqlcmd = "INSERT INTO Users (emailid, password, isCloudAuditor) VALUES('"+emailid+"', '"+password+"', '"+str(isCloudAuditor)+"')"
    if operation == "Edit" :
        print("edit inside")
        sqlcmd = "UPDATE Users SET emailid = '"+emailid+"', password = '"+password+"', isCloudAuditor = '"+str(isCloudAuditor)+"' WHERE userID = '"+unqid+"'"
    if operation == "Delete" :
        sqlcmd = "DELETE FROM Users WHERE userID = '"+unqid+"'" 
    print(operation, sqlcmd)
    if sqlcmd == "" :
        return redirect(url_for('Error')) 
    cur1.execute(sqlcmd)
    cur1.commit()
    conn1.close()
    #return render_template('UserListing.html', processResult="Success!!!. Data Uploaded. ")
    if 'username' in session:
        return redirect(url_for("UserListing"))
    return render_template('ErrorPage.html')





@app.route("/DoctorListing")

def DoctorListing():
    global msgText, msgType, isDoc
    print("DoctorListing Called")
    searchData = request.args.get('searchData')
    if searchData == None:
        searchData = "";
    conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cursor = conn2.cursor()
    sqlcmd1 = "SELECT doctorID, doctorName, specialization, contactnbr FROM Doctors WHERE doctorName like '%"+searchData+"%'"
    print(sqlcmd1)
    cursor.execute(sqlcmd1)
    records = []
    
    while True:
        dbrow = cursor.fetchone()
        if not dbrow:
            break
        row = DoctorModel(dbrow[0], dbrow[1], dbrow[2], dbrow[3])
        records.append(row)
    if 'username' in session:
        if(isDoc):
            template = "DocCommon.html"
        else:
            template = "Common.html"
        return render_template('DoctorListing.html', records=records, searchData=searchData, template=template)
    return render_template('ErrorPage.html')


@app.route("/DoctorOperation")
def DoctorOperation():
    global msgText, msgType
    operation = request.args.get('operation')
    unqid = ""
    row = DoctorModel(0, "", "", "")
    row = None
    if operation != "Create" :
        unqid = request.args.get('unqid').strip()
        conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
        cursor = conn2.cursor()
        sqlcmd1 = "SELECT * FROM Doctors WHERE doctorID = '"+unqid+"'"
        cursor.execute(sqlcmd1)
        while True:
            dbrow = cursor.fetchone()
            if not dbrow:
                break
            row = DoctorModel(dbrow[0], dbrow[1], dbrow[2], dbrow[3], dbrow[4], dbrow[5])
    if 'username' in session:
        return render_template('DoctorOperation.html', row = row, operation=operation )
    return render_template('ErrorPage.html')


'''
This route will be called when the processUploadImage will be clicked (ie the inner page) is called from the browser.
This means that when the processUploadImage url is triggered (means clicking the submit button) processUploadData method is called.

'''

@app.route("/ProcessDoctorOperation",methods = ['POST'])
def ProcessDoctorOperation():
    global msgText, msgType
    operation = request.form['operation']
    if operation != "Delete" :
        doctorname= request.form['doctorName']
        specialization= request.form['specialization']
        contactNbr= request.form['contactNbr']
        emailID= request.form['emailID']
        address= request.form['address']

    
    unqid = request.form['unqid'].strip()
    
    
    conn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cur1 = conn1.cursor()
    
    
    if operation == "Create" :
        sqlcmd = "INSERT INTO Doctors (doctorname, specialization, contactNbr,  emailID, address) VALUES('"+doctorname+"', '"+specialization+"', '"+contactNbr+"', '"+emailID+"', '"+address+"')"
    if operation == "Edit" :
        print("edit inside")
        sqlcmd = "UPDATE Doctors SET doctorname = '"+doctorname+"', specialization = '"+specialization+"', contactNbr = '"+contactNbr+"', emailID = '"+emailID+"', address = '"+address+"' WHERE doctorID = '"+unqid+"'" 
    if operation == "Delete" :
        sqlcmd = "DELETE FROM Doctors WHERE doctorID = '"+unqid+"'" 
    print(operation, sqlcmd)
    if sqlcmd == "" :
        return redirect(url_for('Error')) 
    cur1.execute(sqlcmd)
    cur1.commit()
    conn1.close()
    #return render_template('DoctorListing.html', processResult="Success!!!. Data Uploaded. ")
    if 'username' in session:
        return redirect(url_for("DoctorListing"))
    return render_template('ErrorPage.html')



@app.route("/PatientListing")

def PatientListing():
    global msgText, msgType, isDoc
    print("PatientListing Called")
    searchData = request.args.get('searchData')
    if searchData == None:
        searchData = "";
    conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cursor = conn2.cursor()
    sqlcmd1 = "SELECT patientID, patientName, doctorID, disease, contactNbr, emailID, address FROM Patients WHERE patientName like '%"+searchData+"%'"
    print(sqlcmd1)
    cursor.execute(sqlcmd1)
    records = []
    
    while True:
        dbrow = cursor.fetchone()
        if not dbrow:
            break
        
        conn3 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
        cursor3 = conn3.cursor()
        sqlcmd3 = "SELECT doctorID, doctorName FROM Doctors WHERE doctorID = '"+str(dbrow[2])+"'"
        cursor3.execute(sqlcmd3)
        dbrow3 = cursor3.fetchone()
        if dbrow3:
            doc = DoctorModel(dbrow3[0], dbrow3[1])
        
        row = PatientModel(dbrow[0], dbrow[1], doc, dbrow[3], dbrow[4], dbrow[5], dbrow[6])
        records.append(row)
    if 'username' in session:
        print(isDoc)
        if (isDoc):
            template = "DocCommon.html"
        else:
            template = "Common.html"
        return render_template('PatientListing.html', records=records, searchData=searchData, template=template)
    return render_template('ErrorPage.html')


@app.route("/PatientOperation")
def PatientOperation():
    global msgText, msgType
    operation = request.args.get('operation')
    unqid = ""
    doc = DoctorModel(0, "")
    row = PatientModel(0, "", doc, "")
    doctors = []
    conn3 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cursor3 = conn3.cursor()
    sqlcmd3 = "SELECT doctorID, doctorName FROM Doctors ORDER BY doctorName"
    cursor3.execute(sqlcmd3)
        
    while True:
        dbrow3 = cursor3.fetchone()
        if dbrow3:
            doc = DoctorModel(dbrow3[0], dbrow3[1])
            doctors.append(doc)
        else:
            break
    if operation != "Create" :
        unqid = request.args.get('unqid').strip()
        conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
        cursor = conn2.cursor()
        sqlcmd1 = "SELECT patientID, patientName, doctorID, disease, contactNbr, emailID, address FROM Patients WHERE patientID = '"+unqid+"'"
        cursor.execute(sqlcmd1)
        while True:
            dbrow = cursor.fetchone()
            if not dbrow:
                break
            print("dbrow[5]", dbrow[5])
            
            conn3 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
            cursor3 = conn3.cursor()
            sqlcmd3 = "SELECT doctorID, doctorName FROM Doctors WHERE doctorID = '"+str(dbrow[2])+"'"
            cursor3.execute(sqlcmd3)
            dbrow3 = cursor3.fetchone()
            if dbrow3:
                doc = DoctorModel(dbrow3[0], dbrow3[1])
            row = PatientModel(dbrow[0], dbrow[1], doc, dbrow[3], dbrow[4], dbrow[5], dbrow[6])
        
        
    if 'username' in session:
        return render_template('PatientOperation.html', row = row, operation=operation, doctors=doctors )
    return render_template('ErrorPage.html')


'''
This route will be called when the processUploadImage will be clicked (ie the inner page) is called from the browser.
This means that when the processUploadImage url is triggered (means clicking the submit button) processUploadData method is called.

'''

@app.route("/ProcessPatientOperation",methods = ['POST'])
def ProcessPatientOperation():
    global msgText, msgType
    operation = request.form['operation']
    if operation != "Delete" :
        patientName= request.form['patientName']
        doctorID= request.form['doctorID']
        disease= request.form['disease']
        contactNbr= request.form['contactNbr']
        emailID= request.form['emailID']
        address= request.form['address']

    
    unqid = request.form['unqid'].strip()
    
    
    conn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cur1 = conn1.cursor()
    
    
    if operation == "Create" :
        sqlcmd = "INSERT INTO Patients (patientName, doctorID, disease, contactNbr, emailID, address) VALUES('"+patientName+"','"+doctorID+"',  '"+disease+"', '"+contactNbr+"', '"+emailID+"', '"+address+"')"
    if operation == "Edit" :
        print("edit inside")
        sqlcmd = "UPDATE Patients SET patientName = '"+patientName+"', doctorID = '"+doctorID+"', disease = '"+disease+"', contactNbr = '"+contactNbr+"', emailID = '"+emailID+"', address = '"+address+"' WHERE patientID = '"+unqid+"'" 
    if operation == "Delete" :
        sqlcmd = "DELETE FROM Patients WHERE patientID = '"+unqid+"'" 
    print(operation, sqlcmd)
    if sqlcmd == "" :
        return redirect(url_for('Error')) 
    cur1.execute(sqlcmd)
    cur1.commit()
    conn1.close()
    #return render_template('PatientListing.html', processResult="Success!!!. Data Uploaded. ")
    if 'username' in session:
        return redirect(url_for("PatientListing"))
    return render_template('ErrorPage.html')



@app.route("/EHRRecordListing")

def EHRRecordListing():
    global msgText, msgType, isDoc
    print("EHRRecordListing Called")
    print(isDoc)
    searchData = request.args.get('searchData')
    if searchData == None:
        searchData = "";
    conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cursor = conn2.cursor()
    sqlcmd1 = "SELECT ehrRecordID, effDate, EHRRecords.doctorID, EHRRecords.patientID,  EHRRecords.disease,prescriptionFileName, isBlindedFileGenerated FROM EHRRecords INNER JOIN Patients ON Patients.patientID = EHRRecords.patientID WHERE patientName like '%"+searchData+"%'"
    print(sqlcmd1)
    cursor.execute(sqlcmd1)
    records = []
    
    while True:
        dbrow = cursor.fetchone()
        if not dbrow:
            break
    
        conn3 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
        cursor3 = conn3.cursor()
        sqlcmd3 = "SELECT doctorID, doctorName FROM Doctors WHERE doctorID = '"+str(dbrow[2])+"'"
        cursor3.execute(sqlcmd3)
        dbrow3 = cursor3.fetchone()
        if dbrow3:
            doc = DoctorModel(dbrow3[0], dbrow3[1])
        
        conn4 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
        cursor4 = conn4.cursor()
        sqlcmd4 = "SELECT patientID, patientName FROM Patients WHERE patientID = '"+str(dbrow[3])+"'"
        cursor4.execute(sqlcmd4)
        dbrow4 = cursor4.fetchone()
        if dbrow4:
            pat = PatientModel(dbrow4[0], dbrow4[1])
        row = EHRRecordModel(dbrow[0], dbrow[1], pat, doc, dbrow[4], isBlindedFileGenerated = dbrow[6])
        records.append(row)
    if 'username' in session:
        if (isDoc):
            template = "DocCommon.html"
        else:
            template = "Common.html"
        return render_template('EHRRecordListing.html', records=records, searchData=searchData, template=template)
    return render_template('ErrorPage.html')


@app.route("/EHRRecordOperation")
def EHRRecordOperation():
    global msgText, msgType
    operation = request.args.get('operation')
    unqid = ""
    row = EHRRecordModel(0, "", "", "")
    
    conn3 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cursor3 = conn3.cursor()
    sqlcmd3 = "SELECT doctorID, doctorName FROM Doctors ORDER BY doctorName"
    cursor3.execute(sqlcmd3)
    doctors = []
    while True:
        dbrow3 = cursor3.fetchone()
        if dbrow3:
            doc = DoctorModel(dbrow3[0], dbrow3[1])
            doctors.append(doc)
        else:
            break
    
    sqlcmd3 = "SELECT patientID, patientName FROM Patients ORDER BY patientName"
    cursor3.execute(sqlcmd3)
    patients = []
    while True:
        dbrow3 = cursor3.fetchone()
        if dbrow3:
            pat = PatientModel(dbrow3[0], dbrow3[1])
            patients.append(pat)
        else:
            break
        
        
    if operation != "Create" :
        unqid = request.args.get('unqid').strip()
        conn2 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
        cursor = conn2.cursor()
        sqlcmd1 = "SELECT * FROM EHRRecords WHERE ehrRecordID = '"+unqid+"'"
        cursor.execute(sqlcmd1)
        dbrow = cursor.fetchone()
        if dbrow:
            
            sqlcmd3 = "SELECT doctorID, doctorName FROM Doctors WHERE doctorID = '"+str(dbrow[3])+"'"
            cursor3.execute(sqlcmd3)
            dbrow3 = cursor3.fetchone()
            if dbrow3:
                doc = DoctorModel(dbrow3[0], dbrow3[1])
            
            sqlcmd3 = "SELECT patientID, patientName FROM Patients WHERE patientID = '"+str(dbrow[2])+"'"
            cursor3.execute(sqlcmd3)
            dbrow3 = cursor3.fetchone()
            if dbrow3:
                pat = PatientModel(dbrow3[0], dbrow3[1])
            
            row = EHRRecordModel(dbrow[0], dbrow[1], pat, doc, dbrow[4], dbrow[5], dbrow[6])
        
    if 'username' in session:
        return render_template('EHRRecordOperation.html', row = row, operation=operation, doctors=doctors, patients=patients )
    return render_template('ErrorPage.html')


@app.route("/ProcessEHRRecordOperation",methods = ['POST'])
def ProcessEHRRecordOperation():
    global msgText, msgType
    print("1111")
    operation = request.form['operation']
    isBlindedFileGenerated = request.form['isBlindedFileGenerated'].strip()
    if isBlindedFileGenerated == "True":
        return redirect(url_for("EHRRecordListing"))
    if operation != "Delete" :
        effDate= request.form['effDate']
        patientID= request.form['patientID']
        doctorID= request.form['doctorID']
        disease= request.form['disease']


    unqid = request.form['unqid'].strip()
    
    prescriptionFileName = ""
    if len(request.files) != 0 :
        file = request.files['filetoupload']
        if file.filename != '':
            prescriptionFileName = file.filename
            f = os.path.join('static/UPLOADED_DATA', prescriptionFileName)
            file.save(f)
    conn1 = pypyodbc.connect('Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1', autocommit=True)
    cur1 = conn1.cursor()
    print("2222")
    
    if operation == "Create" :
        sqlcmd = "INSERT INTO EHRRecords (effDate, patientID, doctorID, disease, prescriptionFileName) VALUES('"+effDate+"', '"+str(patientID)+"','"+str(doctorID)+"',  '"+disease+"', '"+prescriptionFileName+"')"
    if operation == "Edit" :
        print("edit inside")
        if prescriptionFileName == "" :
            sqlcmd = "UPDATE EHRRecords SET effDate = '"+effDate+"', patientID = '"+str(patientID)+"', doctorID = '"+str(doctorID)+"', disease = '"+disease+"' WHERE ehrRecordID = '"+unqid+"'" 
        else:
            sqlcmd = "UPDATE EHRRecords SET effDate = '"+effDate+"', patientID = '"+str(patientID)+"', doctorID = '"+str(doctorID)+"', disease = '"+disease+"', prescriptionFileName = '"+prescriptionFileName+"' WHERE ehrRecordID = '"+unqid+"'" 
    if operation == "Delete" :
        sqlcmd = "DELETE FROM EHRRecords WHERE ehrRecordID = '"+unqid+"'" 
    print(operation, sqlcmd)
    if sqlcmd == "" :
        return redirect(url_for('Error')) 
    cur1.execute(sqlcmd)
    cur1.commit()
    conn1.close()
    print("3333")
    #return render_template('EHRRecordListing.html', processResult="Success!!!. Data Uploaded. ")
    if 'username' in session:
        return redirect(url_for("EHRRecordListing"))
    return render_template('ErrorPage.html')


@app.route("/FrmCancel")
def FrmCancel():
    if 'username' in session:
        return render_template('Dashboard.html')
    return render_template('ErrorPage.html')

if __name__ == "__main__":
    app.run(port=9091)
