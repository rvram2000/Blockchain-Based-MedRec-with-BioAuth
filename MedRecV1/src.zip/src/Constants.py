serverName = "localhost"
databaseName = "IndentityBasedIntegrityAuditingV1"
connString = 'Driver={ODBC Driver 17 for SQL Server};Server=localhost;Port=1433;Integrated_Security=true;Database=IndentityBasedIntegrityAuditingV1;Uid=SA;Pwd=Beg@0!=1'